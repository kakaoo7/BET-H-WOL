const wol = require('wol');
const assert = require('assert');


const MAC = 'a4-30-7a-89-db-12';//MAC address of the device to Turn ON
// const MAC = '54-3a-d6-c7-a9-de';//MAC address of the device to Turn ON
// const MAC = '8c-ea-48-e7-d8-c4';//MAC address of the device to Turn ON

const packet = wol.createMagicPacket(MAC); // Generates MagicPacket to send Wak signal to device

wol.wake(MAC, function(err, res){// Sends a wake up signal to device
    console.log(res);
});
